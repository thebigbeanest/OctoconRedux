----------------------------------------
DEFCON: 8 Player Build Prerelase v1.0
By: Fiiral, Sievert and FasterThanRaito
----------------------------------------

This is a modified build of the game DEFCON: Everybody Dies by Introversion Software. This build is meant to overcome the six-player limit hardcoded into the vanilla game and accomodate eight different players simultaneously.

This package contains three files:
1) The actual built modded executable, which will replace the vanilla executable
2) A mods folder, which contains the companion mod required for this build to work properly
3) This README file

Installation Guide:

1) Create a backup of your vanilla defcon.exe.
2) Copy "defcon.exe" and "mods" from this .zip file and drag and drop them into your DEFCON folder.
3) Windows may ask to merge the "mods" folder if you already have one in the DEFCON directory. Tell it to merge.
4) Run the game.
5) From the main menu, click on the "Mods" button to open the mod menu.
6) Click on "DEFCON: 8 Players" in the mod menu, and hit "Activate".
7) Enjoy!

Notes:

- All players must have the same executable installed, as well as the same companion mod, unless they use another map mod which accomodates 8 players.
- This build is Windows-only. It will likely not run on Linux or Mac.
- This mod will NOT work unless the copy of DEFCON is purchased for Introversion Software or a licensed distributor (such as Steam).
- The license agreement for DEFCON source code applies. End users are allowed to modify the modded game subject to the same license.
- This is NOT a cracked version of the game. Code relating to purchase authentication is not modified in any way. You still need to buy the game.

Credits:

Introversion Software: DEFCON game, source
Fiiral: Initial build, 8-player support, companion mod, patch .diff
Sievert: Quality control, bug fixing, city fixes, menu and localization updates, readme
FasterThanRaito: Quality control, territories, color scheme, city and coastline fixes
wan may: Build guide, game documentation, C++ help, CMake help, build environment help

---------
Changelog
---------

Prerelease v1.0:
- Added two new player colors, pink and purple
- Added support for eight teams in the lobby and in-game
- Changed the maximum number of teams in the server display window to eight to properly show empty/full player slots
- Relabelled team "Turq" to "Cyan"

- Changed territories to accomodate new teams: North America, South America, Europe+Greenland, Russia+Kazakhstan, Middle East+North Africa, Sub-Saharan Africa, South Asia+Oceania, and East Asia
- Various minor changes to territories, such as cleaner borders and sensible territory inclusion
- Changed travel nodes around the Philippines to allow passage around and into the South China Sea rather than straight through
- Added travel nodes to connect through the Bering Strait to allow easier passage
- Rounded out China's coastline so that random cities don't appear to be in the middle of the Taiwan strait

- Rebalanced populations by metropolitan area, changes are minor but city data should be more accurate proportionally
- Changed the capital for the Philippines to Manila instead of Quezon City
- Fixed bugged cities in Algeria and Benin, they now show properly instead of random British cities
- Fixed Vladivostok, Miami and Copenhagen not placing properly
- Added Pyongyang to the cities file for North Korea
- Moved Jeddah onto land so that it does not appear to be in the middle of the Red Sea
- Moved San Francisco closer to the west coast of the United States
- Moved Las Vegas to it's proper place, it was east of Santa Fe before
- Deleted a duplicate entry of St. John, New Brunswick
- Deleted a duplicate entry of Manila, Philippines
- Deleted Oroumich, Iran from the list as it is the same city as Rezaiyeh 
- Deleted Kananga, Zaire from the list as it is the same city as Luluabourg 
- Cities which previously included a province or state in its name no longer do so
- Renamed certain cities with bizarre spellings and formatting
- Unabbreviated USA and USSR when country names are displayed, now they are simply displayed as "United States" and "Soviet Union"
- North and South Korean cities properly display "North Korea" and "South Korea" instead of just "Korea"
- North and South Vietnamese cities display "North Vietnam" and "South Vietnam" instead of just "Viet Nam"
- Shortened various coutnry names in city data that were unnecessarily long (East Germany, Libya, Syria, Cambodia)
- Post-Soviet states have all their cities properly marked as their respective country rather than just the capital and major cities
- Renamed Ho Chi Minh City to Saigon and marked it as a capital so that it would not get overwritten by Phnom Penh during city placement

- Added DEFCON Discord link as splash text
- Updated each localization to properly display color text and tutorial text for correct matchups
- Changed text for DEFCON version on main menu to display build version and developers