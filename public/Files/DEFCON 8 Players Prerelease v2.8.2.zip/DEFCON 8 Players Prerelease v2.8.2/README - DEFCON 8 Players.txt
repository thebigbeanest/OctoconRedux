----------------------------------------
DEFCON: 8-Player Build Prerelease v1.2
By: Fiiral, Sievert and FasterThanRaito
----------------------------------------

This is a modified build of the game DEFCON: Everybody Dies by Introversion Software. This build is meant to overcome the six-player limit hardcoded into the vanilla game and accomodate eight different players simultaneously.
This mod also works an an all-around enhancement for the game which fixes some territory gaps and bad city data.
It is built on top of MINICOM by bert_the_turtle, the minimal community enhanced version of DEFCON which includes bugfixes, performance improvements, and improvements to unit behavior.

This package contains the following files:
1) The actual built modded executable, which will replace the vanilla executable
2) A data folder, which overrides the territory/coastline/city data in main.dat
3) A mods folder, which contains the adapted All Cities mod and vanilla reversion mods for MINICOM 
4) A video installation guide
5) This README file
6) The README file included with MINICOM
7) The Developer License Agreement for DEFCON's source code

Installation Guide:
1) Copy your DEFCON install folder to somewhere else. You will use this new directory to run 8-player games without having to uninstall every time you want to go back to normal. Name it something like "DEFCON - 8 Players".
2) In the new DEFCON install folder, copy "defcon.exe", "data", and "mods" from this .zip file and drag and drop them into your DEFCON folder.
3) In your Steam library, at the bottom left of the window, there should be a "Add a Game" button with a plus. Click that, and click "Add a Non-Steam game".
4) Click "Browse..." and navigate to your new modded DEFCON install. Select it.
5) Click "Add Selected Programs".
6) Right click the version of DEFCON you added to your library, and click "Properties".
7) Next to the icon, it should say "defcon". Rename this to something like "DEFCON: 8 Players". Hit the X in the top right corner of this window.
8) You can now run the 8-player build from your Steam library.

Notes:
- All players must be running the same build of the game.
- Mods that require MINICOM to run will also run on this build of the game.
- This build is not currently Dedcon compatible. Dedcon is hardcoded to only support a maximum of six and it's source is currently unavailable.
- This build is Windows-only. It will likely not run on Linux or Mac.
- This mod will NOT work unless the copy of DEFCON is purchased for Introversion Software or a licensed distributor (such as Steam).
- The license agreement for DEFCON source code applies. End users are allowed to modify the modded game subject to the same license.
- This is NOT a cracked version of the game. Code relating to purchase authentication is not modified in any way. You still need to buy the game.

Credits:
- Introversion Software: DEFCON development, source
- bert_the_turtle: MINICOM development
- Fiiral: Initial build, 8-player support, folder structure, patch .diff
- Sievert: Quality control, bug fixing, city fixes, menu and localization updates, readme, icon graphic
- FasterThanRaito: Quality control, territories, color scheme, city and coastline fixes
- wan may: Build guide, game documentation, C++ help, CMake help, build environment help
- photophobic: Build environment help
- KezzaMcFezza: Icon resource file

Prerelease Testers:
- Ben Herr
- Erroneous
- GoodNight
- KezzaMcFezza
- Laika
- Lævateinn
- photophobic
- Red Duck
- Very Fine Art
- wan may

MINICOM Contributors:
- amoskvin
- bert_the_turtle
- jhkrischel
- multimania
- sysctl

---------
Changelog
---------

Prerelease v1.0 (Released 6/30/2024):
- Added two new player colors, pink and purple
- Added support for eight teams in the lobby and in-game
- Changed the maximum number of teams in the server display window to eight to properly show empty/full player slots
- Relabelled team "Turq" to "Cyan"

- Changed territories to accomodate new teams: North America, South America, Europe+Greenland, Russia+Kazakhstan, Middle East+North Africa, Sub-Saharan Africa, South Asia+Oceania, and East Asia
- Various minor changes to territories, such as cleaner borders and sensible territory inclusion
- Changed travel nodes around the Philippines to allow passage around and into the South China Sea rather than straight through
- Added travel nodes to connect through the Bering Strait to allow easier passage
- Rounded out China's coastline so that random cities don't appear to be in the middle of the Taiwan strait

- Rebalanced populations by metropolitan area, changes are minor but city data should be more accurate proportionally
- Changed the capital for the Philippines to Manila instead of Quezon City
- Fixed bugged cities in Algeria and Benin, they now show properly instead of random British cities
- Fixed Vladivostok, Miami and Copenhagen not placing properly
- Added Pyongyang to the cities file for North Korea
- Moved Jeddah onto land so that it does not appear to be in the middle of the Red Sea
- Moved San Francisco closer to the west coast of the United States
- Moved Las Vegas to its proper place, it was east of Santa Fe before
- Deleted a duplicate entry of St. John, New Brunswick
- Deleted a duplicate entry of Manila, Philippines
- Deleted Oroumich, Iran from the cities list as it is the same city as Rezaiyeh 
- Deleted Kananga, Zaire from the cities list as it is the same city as Luluabourg 
- Cities which previously included a province or state in its name no longer do so
- Renamed certain cities with bizarre spellings and formatting
- Unabbreviated USA and USSR when country names are displayed, now they are simply displayed as "United States" and "Soviet Union"
- North and South Korean cities properly display "North Korea" and "South Korea" instead of just "Korea"
- North and South Vietnamese cities display "North Vietnam" and "South Vietnam" instead of just "Viet Nam"
- Shortened various country names in city data that were unnecessarily long (East Germany, Libya, Syria, Cambodia)
- Post-Soviet states have all their cities properly marked as their respective country rather than just the capital and major cities
- Renamed Ho Chi Minh City to Saigon and marked it as a capital so that it would not get overwritten by Phnom Penh during city placement

- Added DEFCON Discord link as splash text
- Updated each localization to properly display color text and tutorial text for correct matchups
- Changed text for DEFCON version on main menu to display build version and developers

Prerelease v1.1 (Released 7/7/2024):
- Removed the panic button/boss key as it doesn't have a real use and just confuses people unfamiliar with it 
- Added a custom icon to the program to differentiate it from vanilla DEFCON 
- Fixed right-facing airbases/carriers/subs from having offset smallnuke/smallbomber/smallfighter sprites (bug that popped up in Prerelease v1.0)
- Moved modified game resources into a new data directory instead of having to activate a companion mod
- Packaged a modified version of All Cities mod with the build
- Packaged an 8-Player Cold War mod by FasterThanRaito with the build
- Gave Sakhalin to Russia's territory
- Gave Cuba, Hispaniola, Puerto Rico, and Jamaica to North America
- Shaved some territory off of southern Spain to avoid Europe placing in Morocco
- Changed travel nodes around the Carribean islands to allow for naval passage into the Gulf of Mexico and the Carribean Sea
- Deleted Kermanshah, Iran from the cities list as it is the same city as Bakhtaran
- Changed the Rolling Demo to show 8 players instead of 3
- Added an installation video guide

Prerelease v1.2 (7/14/2024):
- Changed the game base from DEFCON to MINICOM
- Undid MINICOM's feature which stored preferences and authkey files in Documents/My Games
- Reformat and clean up MINICOM's packaged vanilla reversion mods, they will be the only mods packaged from the start
- Removed Cold War: 8 Players and All Cities: 8 Players from the package, they will be available on the modlist
- Removed Panic Key dropdown in Options since functionality was removed in Prerelease v1.1
- Added a game option which lets you scale the number of units in a game. Mostly intended to allow cancelling out more units on a larger world scale
- Moved Discord splash message to localization files and given proper translations instead of being hardcoded to English
- Fixed bug where the last language in the options menu would display twice
- Fixed Port Moresby and Bandar Seri Begawan not appearing
- Shortened "Brunei Darussalam" to "Brunei"
- Temporarily changed the version string in universal_include.h to get server compatibility working
- Added Port Moresby as an available city
- Added cities to Antarctica in preperation for integration with 10 player modes