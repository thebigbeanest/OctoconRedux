This is a community-modified version of DEFCON by Introversion Software
distributed under the terms of the developer's licence agreement.
 To run it, you need an original copy of DEFCON first, bought from 
Introversion Software directly or a licensed distributor; it is taken 
as sufficient proof if you have a license key stored in the default
location or can enter one when prompted. The original license agreement
of DEFCON still applies to this software; it is attached below.

A copy of the developer license is also included for reference as 
DEVELOPER_LICENSE_AGREEMENT.txt; note however that it does not apply 
to you as a user of this software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

================================================

MINICOM aims to eliminate the remaining bugs and other problems 
of DEFCON while trying to keep the intended feel of the game or 
what the community turned it into by now. Future changes may
go beyond this mission statement, but if they do, they will be
optional. 

================================================

Some important differences to plain Defcon you should know about:

User configuration files and data are now stored in different locations.
Windows: Screenshots are stored in <My Pictures>/Defcon Screenshots/,
  all other data (preferences.txt, authkey, debug.txt) in 
  <My Documents>/My Games/Defcon.
Linux: debug.txt is still in /tmp, everything else in ~/.defcon.
Mac: no changes.

Mods can now be in two places, with the program installation (the System Mods)
and in the user's home directory (User Mods). User mods override system mods of
the same name and version. Locations:
Windows: System mods are in <Installation Directory>/mods, User mods in
         <My Documents>/My Games/Defcon/mods.
Linux: System mods are in <Installation Directory>/mods, User mods in
       ~/.defcon/mods
Mac: System mods are inside the app bundle and only really useful for bundled mods;
     User mods are in Library/Application Support/DEFCON/mods.
It is recommended you use the User Mod directory for your installed mods.

New moddable file data/worldoptions.txt:
This file stores world rules in greater detail than game options would allow for.
Its modding rules are slightly different than for normal files: normally, if you
mod a file, it will be read from the highest priority mod that contains it. This 
file is read from ALL mods, first from the lower priority ones, last from the 
higher priority ones. That way, individual settings from higher priority mods
override individual settings from lower priority mods.

================================================

Contributors outside of Introversion (in alphabetical order):

Forum name         | Real name           | contact/aliases
------------------------------------------------------------------
amoskvin           | ?                   |
bert_the_turtle    | Manuel Moos         | z-man@users.sf.net / z-man
jhkrischel         | ?                   | 
multimania         | ?                   |
sysctl             | ?                   |

================================================

Original license for DEFCON: 

LICENSE AGREEMENT AND LIMITED WARRANTY
PLEASE READ THIS LICENSE CAREFULLY BEFORE USING THE SOFTWARE. THIS DOCUMENT IS AN AGREEMENT BETWEEN YOU AND INTROVERSION SOFTWARE LIMITED. (THE "COMPANY"). THE COMPANY IS WILLING TO LICENSE THE ENCLOSED SOFTWARE TO YOU ONLY ON THE CONDITION THAT YOU ACCEPT ALL THE TERMS CONTAINED IN THIS AGREEMENT. BY USING THE SOFTWARE YOU ARE AGREEING TO BE BOUND BY THE TERMS OF THIS LICENSE.

1. Ownership And License. This is a license agreement and NOT an agreement for sale. The software contained in this package (the "Software") is the property of the Company and/or its Licensors. You own the disk/CD on which the Software is recorded, but the Company and/or its Licensors retain title to the Software and related documentation. Your rights to use the Software are specified in this Agreement, and the Company and/or its Licensors retain all rights not expressly granted to you in this Agreement.

2. Permitted Uses. You are granted the following right to the Software :
(a) Right to Install and Use. You may install and use the Software on a single computer. If you wish to use the Software on more than one computer, please contact the Company for information concerning an upgraded license allowing use of the Software with additional computers.

3. Prohibited Uses. The following uses of the Software are prohibited. You may NOT :
(a) Make or distribute copies of the Software or documentation, or any portion thereof, except as expressly provided in this Agreement.
(b) Use any backup or archival copy of the Software (or allow someone else to use such copy) for any purpose other than to replace the original copy in the event it is destroyed or becomes defective;
(c) Alter, decompile, modify reverse engineer or disassemble the Software, create derivative works based upon the Software, or make any attempt to bypass, unlock or disable any protective or initialization system on the Software;
(d) Rent, lease, sub-license, time-share, or transfer the Software or documentation, or your rights under this Agreement.
(e) Remove or obscure any copyright or trademark notice(s) on the Software or documentation;
(f) Upload or transmit the Software, or any portion thereof, to any electronic bulletin board, network, or other type of multi-use computer system regardless of purpose;
(g) Include the Software in any commercial products intended for manufacture, distribution, or sale; or
(h) Include the Software in any product containing immoral, scandalous, controversial, derogatory, obscene, or offensive works.

4. Termination. This license is effective upon the first use, installation, loading or copying of the Software. You may terminate this Agreement at any time by destruction and disposal of the Software and all related documentation. This license will terminate automatically without notice from the Company if you fail to comply with any provisions of this license. Upon termination, you shall destroy all copies of the Software and any accompanying documentation. 
All provisions of this Agreement as to warranties, limitation of liability, remedies or damages shall survive termination.

5. Copyright Notice. The Company and/or our Licensors hold valid copyright in the Software. Nothing in this Agreement constitutes a waiver of any right under English Copyright law or any other federal or provincial law. This program is protected by English and international copyright laws.

6. Miscellaneous. This Agreement shall be governed by the laws of England. If any provision, or any portion, of this Agreement is found to be unlawful, void, or for any reason unenforceable, it shall be severed from, and shall in no way affect the validity or enforceability of the remaining provisions of the Agreement.

7. Limited  Warranty and Disclaimer of Warranty. For a period of 90 days from the date on which you purchased the Software, the Company warrants that the media on which the Software is supplied will be free from defects in materials and workmanship under normal use. If the Software fails to conform to this warranty, you may, as your sole and exclusive remedy, obtain a replacement free of charge if you return the Software to us with a dated proof of purchase. The Company does not warrant that the Software or its operations or functions will meet your requirements, nor that the use thereof will be without interruption or error.

EXCEPT FOR THE EXPRESS WARRANTY SET FORTH ABOVE, THE COMPANY DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING AND WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. EXCEPT FOR THE EXPRESS WARRANTY SET FORTH ABOVE, THE COMPANY DOES NOT WARRANT, GUARANTEE OR MAKE ANY REPRESENTATION REGARDING THE USE OR THE RESULTS OF THE USE OF THE SOFTWARE IN TERMS OF ITS CORRECTNESS, ACCURACY, RELIABILITY, CURRENTNESS OR OTHERWISE.
IN NO EVENT SHALL THE COMPANY OR ITS EMPLOYEES OR LICENSORS BE LIABLE FOR ANY INCIDENTAL, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR IN CONNECTION WITH THE LICENSE GRANTED UNDER THIS AGREEMENT INCLUDING AND WITH-OUT LIMITATION, LOSS OF USE, LOSS OF DATE, LOSS OF INCOME OR PROFIT, OR OTHER LOSS SUSTAINED AS A RESULT OF INJURY TO ANY PERSON, OR LOSS OF OR DAMAGE TO PROPERTY, OR CLAIMS OF THIRD PARTIES, EVEN IF THE COMPANY OR AN AUTHORIZED REPRESENTATIVE OF THE COMPANY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, IN NO EVENT SHALL LIABILITY OF THE COMPANY FOR DAMAGES WITH RESPECT TO THE SOFTWARE EXCEED THE AMOUNTS ACTUALLY PAID BY YOU, IF ANY, FOR THE SOFTWARE.
SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES SO THE ABOVE LIMITATION OR EXCLUSION MAY NOT APPLY TO YOU.
ACKNOWLEDGEMENT
YOU ACKNOWLEDGE THAT YOU HAVE READ THIS AGREEMENT, UNDERSTAND IT AND AGREE TO BE BOUND BY ITS TERMS AND CONDITIONS. YOU ALSO AGREE THAT THIS AGREEMENT IS THE COMPLETE AND EXCLUSIVE STATEMENT OF THE AGREEMENT BETWEEN YOU AND THE COMPANY AND SUPERCEDES ALL PROPOSALS OR PRIOR ENDORSEMENTS, ORAL OR WRITTEN, AND ANY OTHER COMMUNICATIONS BETWEEN YOU AND THE COMPANY OR ANY REPRESENTATIVE OF THE COMPANY RELATING TO THE SUBJECT MATTER OF THIS AGREEMENT.
